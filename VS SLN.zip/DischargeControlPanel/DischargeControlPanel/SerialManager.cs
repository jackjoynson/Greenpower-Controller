﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DischargeControlPanel
{
  public class SerialManager
   {
      public SerialPort arduinoPort;
      public string portName; // = "COM12";
      public bool discharging = false;

      public  SerialManager()
      {
         arduinoPort = new SerialPort();
      }

      public bool Connect()
      {
         //Do we really want to create new ports here?
         if(portName == null)
         {
            MessageBox.Show("Please select a port in the menu bar...");
            return false;
         }

         if (arduinoPort.IsOpen)
         {
            return true;
         }
         else
         {
            arduinoPort.PortName = portName;
            arduinoPort.BaudRate = 115200;
            arduinoPort.DtrEnable = true;
            //arduinoPort.DataReceived += arduinoBoard_DataReceived;
            try
            {
               arduinoPort.Open();
               if (arduinoPort.IsOpen)
               {
                  return true;
               }
               else
               {
                  return false;
               }
            }
            catch (Exception ex)
            {
               MessageBox.Show(ex.Message);
               return false;
            }
         }

      }

      public bool Disconnect()
      {
         if (arduinoPort.IsOpen)
         {
            arduinoPort.Close();
            if (!arduinoPort.IsOpen)
            {
               return true;
            }
            else
            {
               MessageBox.Show("Failed to close port...");
               return false;
            }
         }
         else
         {
            //MessageBox.Show("Port not open");
            return true;
         }
      }


      public void Start(double currentAim)
      {
         SetCurrentAim(currentAim);
         arduinoPort.Write("G\n");
         discharging = true;
      }

      public void Stop()
      {
         arduinoPort.Write("O\n");
         discharging = false;
      }

      public void SetCurrentAim(double value)
      {
         if (arduinoPort.IsOpen)
         {
            arduinoPort.Write("c" + value.ToString("##"));
         }
      }

      public void Dispose()
      {
         try
         {
            arduinoPort.Close();
         }
         catch { }
         try
         {
            arduinoPort.Dispose();
         }
         catch { }
      }

   }
}
