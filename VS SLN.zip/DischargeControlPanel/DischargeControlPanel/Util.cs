﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Speech.Synthesis;

namespace DischargeControlPanel
{
   class Utilities
   {
      SpeechSynthesizer synthesizer;
      public Utilities()
      {
         initLog();
         synthesizer = new SpeechSynthesizer();
         synthesizer.Volume = 100;  // 0...100
         synthesizer.Rate = -2;     // -10...10
      }

      public string logPath = @"C:\ProgramData\JJS\DischargeRig\Log.txt";

      void initLog()
      {
         if (!File.Exists(logPath))
         {
            if (!Directory.Exists(Path.GetDirectoryName(logPath)))
            {
               Directory.CreateDirectory(Path.GetDirectoryName(logPath));
            }
            File.WriteAllText(logPath, "File created: "+DateTime.Now + Environment.NewLine);
         }
      }

      public void Log(string text)
      {
         try
         {
            File.AppendAllText(logPath, text);
         }
         catch (Exception err)
         {
            MessageBox.Show("Error writing to error log file: " + err + Environment.NewLine);
         }
      }

      public void Speak(string text)
      {
         synthesizer.SpeakAsync(text);
      }
   }
}
